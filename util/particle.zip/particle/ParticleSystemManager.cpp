//
//  ParticleSystemManager.cpp
//  Stoneage
//
//  Created by fanxiaoli on 12-12-16.
//  Copyright (c) 2012年 Home. All rights reserved.
//

#include <iostream>
#include "ParticleSystemManager.h"
#include "Util.h"
#include "UTF8.h"
#include "CircleGeneratorSpace.h"
#include "PointGeneratorSpace.h"
#include "RectGeneratorSpace.h"
#include "LineGeneratorSpace.h"
#include "PathGeneratorSpace.h"
#include "ParticleRender.h"
#include "GenericForce.h"
#include "AirFriction.h"
#include <algorithm>

ParticleSystemManager::ParticleSystemManager()
{
    ParticleSpace::Init();//初始化粒子缓冲源池
    ParticleUtil::InitUtil();//初始化util的float随机数缓冲池
}

ParticleSystemManager::~ParticleSystemManager()
{
    for(hash_map<int, ParticleSystemData*>::iterator it = allData.begin(); it != allData.end(); it ++){
        ParticleSystemData* v = it->second;
        delete v;
    }
    allData.clear();

    for(hash_map<const char*, CCTexture2D*>::iterator it = textures.begin(); it != textures.end(); it ++){
        CCTexture2D* tex = it->second;
        delete tex;
    }
    textures.clear();
    
}

CCTexture2D* ParticleSystemManager::LoadImage(const char* name)
{
//     XCLOG("[ParticleSystemManager::LoadImage][file name===%s]",name);
//   
    CCTexture2D* img = CCTextureCache::sharedTextureCache()->addImage(name);
    if(img != NULL){
        textures[name] = img;
        img->setAntiAliasTexParameters();//抗锯齿(线性过滤)
    }
    return NULL;
}

CCTexture2D* ParticleSystemManager::GetImage(const char* name)
{
    hash_map<const char*, CCTexture2D*>::iterator it = textures.find(name);
    if(it != textures.end() && it->second != NULL){
        return it->second;
    }else{
        return LoadImage(name);
    }
}

ParticleSystem* ParticleSystemManager::AddParticlesSystem(CCNode* node,CCPoint point,int zOder,const char* psName, bool loop, float time, ParticleSystem::PSListener* listener)
{
    ParticleSystem* ps = new ParticleSystem();
    ps->Init(psName);
    if(ps != NULL){
        node->addChild(ps,zOder);
        ps->repeat = loop;
        if(loop && time > ps->life){//循环播放
            ps->maxPlayTime = time;
        }
        ps->setPosition(point);
        ps->SetListener(listener);
        addParticle(ps);
        return ps;
    }
    return NULL;
}

ParticleSystem* ParticleSystemManager::AddParticlesSystem(CCNode* node, int x, int y, const char* psName, int loopCnt, ParticleSystem::PSListener* listener)
{
    ParticleSystem* ps = new ParticleSystem();
    ps->Init(psName);
    if(ps != NULL){
//        particleSystemPool.push_back(ps);
        node->addChild(ps);
        if(loopCnt > 0){
            ps->repeat = true;
            ps->loopCnt = loopCnt;
        }
        ps->setPosition(x, y);
        ps->SetListener(listener);
        addParticle(ps);
        return ps;
    }
    return NULL;
}

void ParticleSystemManager::LoadParticleSystems()
{
    std::string path = cocos2d::CCFileUtils::sharedFileUtils()->fullPathFromRelativePath("particles/particle.bin");
    particle::FileInputStream is(path.c_str());
    if(is.Available())
    {
        int count = is.ReadShort();
        for(int i = 0; i < count; i ++){
            ParticleSystemData* psd = new ParticleSystemData();
            psd->LoadFromStream(is);
            allData[particle::UTF8Hash((char*)psd->name.Data())] = psd;
        }
    }
}

void ParticleSystemManager::addParticle(ParticleSystem* p){
    particle_vector.push_back(p);
}

void ParticleSystemManager::deleteParticle(ParticleSystem* p){
    particle_vector.erase(std::remove(particle_vector.begin(),particle_vector.end(),p));
}

void ParticleSystemManager::particleSystemUpdate(float dtime){
    for (int i=0; i<particle_vector.size(); i++) {
        ParticleSystem* particle = particle_vector.at(i);
        particle->update(dtime);
    }
}
