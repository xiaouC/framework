//
//  ParticleSystemManager.h
//  Stoneage
//
//  Created by fanxiaoli on 12-12-16.
//  Copyright (c) 2012年 Home. All rights reserved.
//

#ifndef Stoneage_ParticleSystemManager_h
#define Stoneage_ParticleSystemManager_h

#include "Generator.h"
#include "ParticleSystem.h"
#include "hash_map.h"
#include <vector.h>
using namespace cocos2d;
class ParticleSystemManager
{
public:
    ParticleSystemManager();
    ~ParticleSystemManager();
    
    inline static ParticleSystemManager& GetInstance(){
        static ParticleSystemManager self;
        return self;
    }
    void OnRender(float ft);
	void OnUpdate(float fDeltaTime);
    void LoadParticleSystems();
    void LoadXMLFiles(const char* filename, ParticleSystem* ps);
    ParticleSystem* AddParticlesSystem(CCNode* node,CCPoint point,int zOder, const char* fileName, bool loop, float time=-1, ParticleSystem::PSListener* listener=NULL);
    ParticleSystem* AddParticlesSystem(CCNode* node, int x, int y, const char* fileName, int loopCnt=-1, ParticleSystem::PSListener* listener=NULL);
    void RemoveParticleSystem(const char* name);
    void RemoveAllParticleSystem();
    CCTexture2D* LoadImage(const char* name);
    CCTexture2D* GetImage(const char* name);
    
    void addParticle(ParticleSystem* p);
    void deleteParticle(ParticleSystem* p);
    std::vector<ParticleSystem*> particle_vector;
    void particleSystemUpdate(float dtime);
public:
    hash_map<int, ParticleSystemData*> allData;//用来存储所有的粒子系统的所有发射器数据
    hash_map<const char*, CCTexture2D*> textures;//粒子系统所用的图片
};


#endif
